package com.lanmei.yidaosu;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class InsulinWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // 更新所有小组件实例
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // 获取今天的数据
        WidgetData data = getTodayData(context);

        // 创建RemoteViews
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_insulin);

        // 设置日期
        views.setTextViewText(R.id.widget_date, data.date);

        // 设置剂量数据
        views.setTextViewText(R.id.dose_breakfast, "早餐：" + getDoseText(data.breakfast));
        views.setTextViewText(R.id.dose_lunch, "午餐：" + getDoseText(data.lunch));
        views.setTextViewText(R.id.dose_dinner, "晚餐：" + getDoseText(data.dinner));
        views.setTextViewText(R.id.dose_long, "长效：" + getDoseText(data.longActing));

        // 设置总量
        views.setTextViewText(R.id.widget_total, "今日总量：" + data.total);

        // 添加点击事件：点击小组件任何地方都打开应用
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // 为整个小组件设置点击事件
        views.setOnClickPendingIntent(R.id.widget_layout, pendingIntent);

        // 更新小组件
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static String getDoseText(int dose) {
        return dose > 0 ? String.valueOf(dose) : "无";
    }

    private static WidgetData getTodayData(Context context) {
        WidgetData data = new WidgetData();

        // 设置日期
        SimpleDateFormat dateFormat = new SimpleDateFormat("M/d", Locale.getDefault());
        data.date = dateFormat.format(new Date());

        try {
            // 获取当前年月
            SimpleDateFormat yearMonthFormat = new SimpleDateFormat("yyyyMM", Locale.getDefault());
            String currentYearMonth = yearMonthFormat.format(new Date());

            // 获取今天日期
            Calendar calendar = Calendar.getInstance();
            int today = calendar.get(Calendar.DAY_OF_MONTH);

            // 读取数据文件
            File dataDir = new File(context.getFilesDir(), "yidaosu");
            File dataFile = new File(dataDir, currentYearMonth + ".txt");

            if (dataFile.exists()) {
                try (BufferedReader reader = new BufferedReader(new FileReader(dataFile))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split(",");
                        if (parts.length == 5) {
                            try {
                                int day = Integer.parseInt(parts[0]);
                                if (day == today) {
                                    // 找到今天的数据
                                    data.breakfast = Integer.parseInt(parts[1]);
                                    data.lunch = Integer.parseInt(parts[2]);
                                    data.dinner = Integer.parseInt(parts[3]);
                                    data.longActing = Integer.parseInt(parts[4]);
                                    data.total = data.breakfast + data.lunch + data.dinner + data.longActing;
                                    break;
                                }
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }

    // 数据类
    static class WidgetData {
        String date = "";
        int breakfast = 0;
        int lunch = 0;
        int dinner = 0;
        int longActing = 0;
        int total = 0;
    }
}