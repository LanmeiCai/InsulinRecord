package com.lanmei.yidaosu;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private TableLayout tableLayout;
    private Map<String, Map<Integer, int[]>> monthlyData;
    private String currentYearMonth;
    private SimpleDateFormat yearMonthFormat;
    private SimpleDateFormat dayFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        yearMonthFormat = new SimpleDateFormat("yyyyMM", Locale.getDefault());
        dayFormat = new SimpleDateFormat("dd", Locale.getDefault());
        currentYearMonth = yearMonthFormat.format(new Date());
        monthlyData = new HashMap<>();
        tableLayout = findViewById(R.id.insulinTable);

        loadMonthlyData();
        refreshTable();
    }

    private void loadMonthlyData() {
        File dataDir = new File(getFilesDir(), "yidaosu");
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }

        File dataFile = new File(dataDir, currentYearMonth + ".txt");
        if (dataFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(dataFile))) {
                String line;
                Map<Integer, int[]> dayDataMap = new HashMap<>();

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 5) {
                        try {
                            int day = Integer.parseInt(parts[0]);
                            int[] doses = new int[4];
                            for (int i = 0; i < 4; i++) {
                                doses[i] = Integer.parseInt(parts[i + 1]);
                            }
                            dayDataMap.put(day, doses);
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                    }
                }
                monthlyData.put(currentYearMonth, dayDataMap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveData(int day, int doseType, int value) {
        if (!monthlyData.containsKey(currentYearMonth)) {
            monthlyData.put(currentYearMonth, new HashMap<>());
        }

        Map<Integer, int[]> dayDataMap = monthlyData.get(currentYearMonth);
        if (!dayDataMap.containsKey(day)) {
            dayDataMap.put(day, new int[4]);
        }

        int[] doses = dayDataMap.get(day);
        doses[doseType] = value;

        File dataDir = new File(getFilesDir(), "yidaosu");
        File dataFile = new File(dataDir, currentYearMonth + ".txt");

        try (FileWriter writer = new FileWriter(dataFile)) {
            for (Map.Entry<Integer, int[]> entry : dayDataMap.entrySet()) {
                StringBuilder sb = new StringBuilder();
                sb.append(entry.getKey());
                for (int dose : entry.getValue()) {
                    sb.append(",").append(dose);
                }
                writer.write(sb.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        updateWidget();
    }

    /**
     * 通知小组件更新
     */
    private void updateWidget() {
        // 发送广播通知小组件更新
        Intent intent = new Intent(this, InsulinWidget.class);
        intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = AppWidgetManager.getInstance(getApplication())
                .getAppWidgetIds(new ComponentName(getApplication(), InsulinWidget.class));
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
        sendBroadcast(intent);
    }
    private void refreshTable() {
        int childCount = tableLayout.getChildCount();
        if (childCount > 1) {
            tableLayout.removeViews(1, childCount - 1);
        }

        Calendar calendar = Calendar.getInstance();
        int today = calendar.get(Calendar.DAY_OF_MONTH);

        List<Integer> daysToShow = new ArrayList<>();
        for (int day = today; day >= 1; day--) {
            daysToShow.add(day);
        }

        for (int day : daysToShow) {
            if (day == today || hasDataForDay(day)) {
                addTableRowForDay(day);
            }
        }
    }

    private boolean hasDataForDay(int day) {
        if (monthlyData.containsKey(currentYearMonth)) {
            Map<Integer, int[]> dayDataMap = monthlyData.get(currentYearMonth);
            if (dayDataMap.containsKey(day)) {
                int[] doses = dayDataMap.get(day);
                for (int dose : doses) {
                    if (dose > 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


    /**
     * 判断当前是否为深色模式
     */
    private boolean isDarkMode() {
        int nightModeFlags = getResources().getConfiguration().uiMode &
                android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    private void addTableRowForDay(int day) {
        TableRow row = new TableRow(this);
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(0, 12, 0, 12); // 增加行间距
        row.setLayoutParams(layoutParams);

        // 日期单元格
        TextView dateText = new TextView(this);
        dateText.setText(String.valueOf(day));
        dateText.setGravity(android.view.Gravity.CENTER);
        dateText.setPadding(16, 20, 16, 20);
        dateText.setTextColor(isDarkMode() ? Color.WHITE : Color.BLACK);
        dateText.setTextSize(16);
        row.addView(dateText);

        int[] doses = getDosesForDay(day);
        final int currentDay = day;

        // 剂量类型名称（用于提示）
        String[] doseTypes = {"早餐", "午餐", "晚餐", "长效"};

        for (int i = 0; i < 4; i++) {
            final int doseType = i;

            // 创建简单的Material Design风格输入框
            EditText editText = new EditText(this);
            editText.setGravity(android.view.Gravity.CENTER);
            editText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            editText.setPadding(8, 16, 8, 16);
            editText.setTextColor(Color.BLACK); // 黑色文本
            editText.setHint(doseTypes[i]);
            editText.setHintTextColor(Color.GRAY);
            editText.setTextSize(14);

            // Material Design样式
            editText.setBackgroundResource(R.drawable.edit_text_background);

            // 设置布局权重
            TableRow.LayoutParams editTextParams = new TableRow.LayoutParams(
                    0, TableRow.LayoutParams.WRAP_CONTENT, 1.0f);
            editTextParams.setMargins(4, 0, 4, 0);
            editText.setLayoutParams(editTextParams);

            if (doses[i] > 0) {
                editText.setText(String.valueOf(doses[i]));
            }

            editText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    try {
                        int value = s.length() > 0 ? Integer.parseInt(s.toString()) : 0;
                        saveData(currentDay, doseType, value);
                        updateTotalForRow(row, currentDay);
                    } catch (NumberFormatException e) {
                        // 忽略无效输入
                    }
                }
            });

            row.addView(editText);
        }

        // 总量显示单元格
        TextView totalText = new TextView(this);
        totalText.setGravity(android.view.Gravity.CENTER);
        totalText.setPadding(16, 20, 16, 20);
        int total = calculateTotal(doses);
        totalText.setText(String.valueOf(total));
        totalText.setTextColor(Color.BLACK); // 黑色文本
        totalText.setTextSize(16);
        totalText.setBackgroundResource(R.drawable.total_background);
        row.addView(totalText);

        tableLayout.addView(row);
    }

    private int[] getDosesForDay(int day) {
        if (monthlyData.containsKey(currentYearMonth)) {
            Map<Integer, int[]> dayDataMap = monthlyData.get(currentYearMonth);
            if (dayDataMap.containsKey(day)) {
                return dayDataMap.get(day);
            }
        }
        return new int[4];
    }

    private int calculateTotal(int[] doses) {
        int total = 0;
        for (int dose : doses) {
            total += dose;
        }
        return total;
    }

    private void updateTotalForRow(TableRow row, int day) {
        int[] doses = getDosesForDay(day);
        int total = calculateTotal(doses);
        TextView totalText = (TextView) row.getChildAt(5);
        totalText.setText(String.valueOf(total));
    }
}